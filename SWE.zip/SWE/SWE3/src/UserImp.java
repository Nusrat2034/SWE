public class UserImp implements User{
    private final String name;

    public UserImp(String name) {
        this.name = name;
    }

    @Override
    public void notify(String genre, String movieName) {
        System.out.println("User " + name + " notified about new " + genre + " movie: " + movieName);
    }
}
