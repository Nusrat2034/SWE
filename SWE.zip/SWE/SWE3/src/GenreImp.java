import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class GenreImp implements Genre{
    public final String genreName;
    public final List<User> users = new ArrayList<>();
    public final ExecutorService executor = Executors.newCachedThreadPool();

    public GenreImp(String genreName) {
        this.genreName = genreName;
    }

    @Override
    public void subscribe(User user) {
        users.add(user);
    }

    @Override
    public void unsubscribe(User user) {
        users.remove(user);
    }

    @Override
    public void notifyUsers(String movieName) {
        for (User user : users) {
            new Thread(() -> user.notify(genreName,movieName)).start();
        }
    }
}
