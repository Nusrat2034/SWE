public class DesiFlix {
    public static void main(String[] args) {

        Genre thriller = new GenreImp("Thriller");
        Genre horror = new GenreImp("Horror");
        Genre comedy = new GenreImp("Comedy");

        User user1 = new UserImp("Alice");
        User user2 = new UserImp("Bob");
        User user3 = new UserImp("Charlie");
        User user4=new UserImp("abc");

        thriller.subscribe(user1);
        thriller.subscribe(user2);
        horror.subscribe(user2);
        comedy.subscribe(user3);
        thriller.subscribe(user4);

        thriller.notifyUsers("Inception");
        horror.notifyUsers("The Conjuring");
        comedy.notifyUsers("The Mask");
    }
}
