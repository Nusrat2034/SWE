public interface User {
    void notify(String genre, String movieName);
}
