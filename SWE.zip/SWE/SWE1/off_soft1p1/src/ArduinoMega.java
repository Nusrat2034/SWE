public class ArduinoMega implements MicroControllers{
    public void addMicrocontroller() {
        System.out.println("Arduino Mega has been added to the system.");
    }
}
