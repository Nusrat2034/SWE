public class RaspberryPi implements MicroControllers{
    public void addMicrocontroller() {
        System.out.println("Raspberry Pi has been added to the system.");
    }
}
