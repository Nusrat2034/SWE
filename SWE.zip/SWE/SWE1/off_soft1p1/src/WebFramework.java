public interface WebFramework {
    void useFramework();
}
