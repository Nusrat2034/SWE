public class WiFi implements InternetConnection{
    public void connect() {
        System.out.println("WiFi connection has been added to the system.");
    }
}
