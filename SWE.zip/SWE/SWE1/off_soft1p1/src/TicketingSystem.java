class TicketingSystem {
    private MicroControllers microcontroller;
    private Display display;
    private InternetConnection internetConnection;
    private WebFramework webFramework;

    public TicketingSystem(MicroControllers microcontroller, Display display, InternetConnection internetConnection, WebFramework webFramework) {
        this.microcontroller = microcontroller;
        this.display = display;
        this.internetConnection = internetConnection;
        this.webFramework = webFramework;
    }

    public void showDetails() {
        microcontroller.addMicrocontroller();
        display.addDisplay();
        internetConnection.connect();
        webFramework.useFramework();
    }
}
