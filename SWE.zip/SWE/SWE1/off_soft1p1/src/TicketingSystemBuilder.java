class TicketingSystemBuilder {
    private MicroControllers microcontroller;
    private Display display;
    private InternetConnection internetConnection;
    private WebFramework webFramework;

    public TicketingSystemBuilder setMicrocontroller(MicroControllers microcontroller) {
        this.microcontroller = microcontroller;
        return this;
    }

    public TicketingSystemBuilder setDisplay(Display display) {
        this.display = display;
        return this;
    }

    public TicketingSystemBuilder setInternetConnection(InternetConnection internetConnection) {
        this.internetConnection = internetConnection;
        return this;
    }

    public TicketingSystemBuilder setWebFramework(WebFramework webFramework) {
        this.webFramework = webFramework;
        return this;
    }

    public TicketingSystem build() {
        return new TicketingSystem(microcontroller, display, internetConnection, webFramework);
    }
}
