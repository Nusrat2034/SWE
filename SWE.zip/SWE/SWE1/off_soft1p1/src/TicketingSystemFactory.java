class TicketingSystemFactory {
    public static MicroControllers getMicrocontroller(String type) {
        if (type.equalsIgnoreCase("Basic")) {
            return new ATMega32();
        } else if (type.equalsIgnoreCase("Standard")) {
            return new ArduinoMega();
        } else if (type.equalsIgnoreCase("Advanced") || type.equalsIgnoreCase("Premium")) {
            return new RaspberryPi();
        }
        return null;
    }

    public static Display getDisplay(String type) {
        switch (type.toLowerCase()) {
            case "basic": return new LCDDisplay();
            case "standard": return new LEDDisplay();
            case "advanced": return new OLEDDisplay();
            case "premium": return new TouchScreenDisplay();
            default: return null;
        }
    }

    public static InternetConnection getInternetConnection(String type) {
        switch (type.toLowerCase()) {
            case "wifi": return new WiFi();
            case "ethernet": return new Ethernet();
            case "sim": return new SIMCard();
            default: return null;
        }
    }

    public static WebFramework getWebFramework(String type) {
        switch (type.toLowerCase()) {
            case "django": return new Django();
            case "nodejs": return new NodeJS();
            case "ruby": return new Ruby();
            default: return null;
        }
    }
}
