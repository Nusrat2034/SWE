public class TouchScreenDisplay implements Display{
    public void addDisplay() {
        System.out.println("Touch Screen Display has been added to the system.");
    }
}
