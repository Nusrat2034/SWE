public interface MicroControllers {
    void addMicrocontroller();
}
