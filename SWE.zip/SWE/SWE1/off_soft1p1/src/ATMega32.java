public class ATMega32 implements MicroControllers{
    public void addMicrocontroller() {
        System.out.println("ATMega32 has been added to the system.");
    }
}
