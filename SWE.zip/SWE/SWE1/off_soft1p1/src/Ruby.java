public class Ruby implements WebFramework{
    public void useFramework() {
        System.out.println("Ruby Web Framework has been selected.");
    }
}
