public class Ethernet implements InternetConnection{
    public void connect() {
        System.out.println("Ethernet connection has been added to the system.");
    }
}
