public class NodeJS implements WebFramework{
    public void useFramework() {
        System.out.println("NodeJS Web Framework has been selected.");
    }
}
