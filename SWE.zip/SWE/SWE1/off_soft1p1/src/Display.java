public interface Display {
    void addDisplay();
}
