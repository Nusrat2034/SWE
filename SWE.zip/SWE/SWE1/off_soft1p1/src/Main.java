import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Choose a package (Basic/Standard/Advanced/Premium): ");
        String packageType = sc.nextLine();
        System.out.println("Choose an internet connection (WiFi/Ethernet/SIM): ");
        String internetType = sc.nextLine();
        System.out.println("Choose a web framework (Django/NodeJS/Ruby): ");
        String frameworkType = sc.nextLine();
        TicketingSystemBuilder builder = new TicketingSystemBuilder();
        TicketingSystem system = builder
                .setMicrocontroller(TicketingSystemFactory.getMicrocontroller(packageType))
                .setDisplay(TicketingSystemFactory.getDisplay(packageType))
                .setInternetConnection(TicketingSystemFactory.getInternetConnection(internetType))
                .setWebFramework(TicketingSystemFactory.getWebFramework(frameworkType))
                .build();
        system.showDetails();
    }
}
