public interface InternetConnection {
    void connect();
}
