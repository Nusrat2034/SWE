public class SIMCard implements InternetConnection{
    public void connect() {
        System.out.println("SIM card connection has been added to the system.");
    }
}
