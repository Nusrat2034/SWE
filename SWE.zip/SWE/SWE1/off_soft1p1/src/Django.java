public class Django implements WebFramework{
    public void useFramework() {
        System.out.println("Django Web Framework has been selected.");
    }
}
