public class OLEDDisplay implements Display{
    public void addDisplay() {
        System.out.println("OLED Display has been added to the system.");
    }
}
