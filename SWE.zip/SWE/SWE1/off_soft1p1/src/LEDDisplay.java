public class LEDDisplay implements Display{
    public void addDisplay() {
        System.out.println("LED Display has been added to the system.");
    }
}
