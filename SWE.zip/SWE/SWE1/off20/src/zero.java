public class zero {
    boolean is_chocolate=false;
    boolean is_lactose_free=false;
    int price = 230;

    void  add_top(){
        is_chocolate=true;
        this.price+=60 ;
    }
}
