public interface Shake {
    void  add_top();
}
