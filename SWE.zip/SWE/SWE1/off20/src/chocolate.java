public class chocolate {
    boolean is_chocolate;
    boolean is_lactose_free;
    int price = 230;

    void  add_top(){
      this.price+=60 ;
    }
}
