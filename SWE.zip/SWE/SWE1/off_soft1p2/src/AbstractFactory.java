abstract class AbstractFactory {
    public abstract Account createAccount(String type);
    public abstract Loan createLoan(String type);
}



