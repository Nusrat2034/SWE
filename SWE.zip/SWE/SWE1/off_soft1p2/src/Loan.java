abstract class Loan {
    protected double interestRate;

    public abstract double calculateInterest(int period,int principle);
}
