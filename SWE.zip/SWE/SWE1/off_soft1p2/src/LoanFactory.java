class LoanFactory extends AbstractFactory {
    public Loan createLoan (String type) {
        // Implement logic to create the appropriate account type based on the string
        if (type.equalsIgnoreCase("Regular")) {
            return new RegularLoan();
        }

        else if (type.equalsIgnoreCase("Premium")) {
            return new PremiumLoan();
        }
        else if (type.equalsIgnoreCase("Vip")) {
            return new VipLoan();
        }
        else {
            System.out.println("Wrong input");
            return null;
        }
    }
    public Account createAccount(String type) {
        return null;
    }
}