public class PremiumLoan extends Loan{
    public PremiumLoan() {
        interestRate = 0.12;
    }

    @Override
    public double calculateInterest(int period,int principal) {
        // Implement simple or compound interest calculation logic
        return principal * interestRate * period;
    }
}

