import java.util.Scanner;
//
//public class Main {
//    public static void main(String[] args) {
//        Scanner sc = new Scanner(System.in);
//        int choice = 0; // Initialize choice outside the loop
//
//        // Loop until the user enters 3 (for Exit)
//        while (choice != 3) {
//            System.out.println("Which service do you want?");
//            System.out.println("1. Account");
//            System.out.println("2. Loan");
//            System.out.println("3. Exit");
//
//            System.out.print("Enter your choice: ");
//            choice = sc.nextInt();
//            sc.nextLine(); // To consume the newline
//
//            switch (choice) {
//                case 1:
//                    System.out.println("You selected Account.");
//                    System.out.println("Enter your customer type (Regular, Premium, Vip):");
//                    String AccType = sc.nextLine();
//                    AccountFactory AcF = new AccountFactory();
//                    Account acc = AcF.createAccount(AccType);
//
//                    System.out.print("Enter your period and principle: ");
//                    int period = sc.nextInt();
//                    int principle = sc.nextInt();
//                    sc.nextLine(); // To consume the newline
//
//                    double interest = acc.calculateInterest(period, principle);
//                    System.out.println("Total Interest: " + interest);
//                    break;
//
//                case 2:
//                    System.out.println("You selected Loan.");
//                    System.out.println("Enter your customer type (Regular, Premium, Vip):");
//                    String LoanType = sc.nextLine();
//                    LoanFactory LoanF = new LoanFactory();
//                    Loan loan = LoanF.createLoan(LoanType);
//
//                    System.out.print("Enter your period and principle: ");
//                    int p2 = sc.nextInt();
//                    int pri2 = sc.nextInt();
//                    sc.nextLine(); // To consume the newline
//
//                    double interest2 = loan.calculateInterest(p2, pri2);
//                    System.out.println("Total Interest: " + interest2);
//                    break;
//
//                case 3:
//                    System.out.println("Exiting the program.");
//                    break;
//
//                default:
//                    System.out.println("Invalid choice. Please select 1, 2, or 3.");
//            }
//        }
//
//        sc.close();
//    }
//}
//
public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your choice(Account,Loan): ");
        String factoryChoice = sc.nextLine();

        AbstractFactory factory = FactoryCreator.getFactory(factoryChoice);

        // Use the factory to create the desired product (e.g., a account or a loan)
        if (factory instanceof AccountFactory) {
            System.out.println("Enter your client type(Regular,Premium,Vip): ");
            String client_type = sc.nextLine();
            Account account = ((AccountFactory) factory).createAccount(client_type);
            System.out.println("Enter period and principle:");
            int period = sc.nextInt();
            int principle = sc.nextInt();
            sc.nextLine();
            System.out.println(account.calculateInterest(period,principle));

        }
        else if (factory instanceof LoanFactory) {
            System.out.println("Enter your client type(Regular,Premium,Vip): ");
            String client_type2 = sc.nextLine();
            Loan loan = ((LoanFactory) factory).createLoan(client_type2);
            System.out.println("Enter period and principle:");
            int period2 = sc.nextInt();
            int principle2 = sc.nextInt();
            sc.nextLine();
            System.out.println(loan.calculateInterest(period2,principle2));
        }
        else {
            System.out.println("Invalid factory choice");
        }
    }
}