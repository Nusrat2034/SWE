class PremiumAccount extends Account {
    public PremiumAccount() {
        interestRate = 0.035;
    }

    @Override
    public double calculateInterest(int period,int principal) {
        // Implement simple or compound interest calculation logic
        return principal * interestRate * period;
    }
}