class AccountFactory extends AbstractFactory {
    public Account createAccount(String type) {
        // Implement logic to create the appropriate account type based on the string
        if (type.equalsIgnoreCase("Regular")) {
            return new RegularAccount();
        } else if (type.equalsIgnoreCase("Premium")) {
            return new PremiumAccount();
        } else if (type.equalsIgnoreCase("Vip")) {
            return new VipAccount();
        } else {
            System.out.println("Wrong input");
            return null;
        }
    }

    @Override
    public Loan createLoan(String type) {
        return null;
    }
}