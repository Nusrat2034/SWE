public class FactoryCreator {
    public static AbstractFactory getFactory(String type){
        if(type.equalsIgnoreCase("Account")){
         return new AccountFactory();
        }

        else if(type.equalsIgnoreCase("Loan")){
            return new LoanFactory();
        }

       else {
           return null;
       }
    }
}
