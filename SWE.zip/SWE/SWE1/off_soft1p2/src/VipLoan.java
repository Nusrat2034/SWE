public class VipLoan extends Loan{
    public VipLoan() {
        interestRate = 0.1;
    }

    @Override
    public double calculateInterest(int period,int principal) {
        // Implement simple or compound interest calculation logic
        return principal * interestRate * period;
    }
}

