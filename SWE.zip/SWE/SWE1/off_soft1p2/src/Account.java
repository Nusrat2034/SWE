abstract class Account {
    protected double interestRate;

    public abstract double calculateInterest(int period,int principle);
}