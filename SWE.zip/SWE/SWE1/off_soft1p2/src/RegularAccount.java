class RegularAccount extends Account {
    public RegularAccount() {
        interestRate = 0.025;
    }

    @Override
    public double calculateInterest(int period,int principal) {
        // Implement simple or compound interest calculation logic
        return principal * interestRate * period;
    }
}