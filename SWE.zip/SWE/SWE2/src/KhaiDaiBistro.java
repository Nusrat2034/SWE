import java.util.Scanner;

public class KhaiDaiBistro {
    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.addMenuItem(new IndividualItem("Burger", 300));
        menu.addMenuItem(new IndividualItem("Fries", 100));
        menu.addMenuItem(new IndividualItem("Wedges", 150));
        menu.addMenuItem(new IndividualItem("Shawarma", 200));
        menu.addMenuItem(new IndividualItem("Drink", 25));

        Combo combo1 = new Combo("Combo1");
        combo1.addItem(new IndividualItem("Burger", 300));
        combo1.addItem(new IndividualItem("Fries", 100));
        combo1.addItem(new IndividualItem("Drink", 0));
        menu.addMenuItem(combo1);

        Combo combo2 = new Combo("Combo2");
        combo2.addItem(new IndividualItem("Shawarma", 200));
        combo2.addItem(new IndividualItem("Drink", 15));
        menu.addMenuItem(combo2);
        menu.viewMenu();
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Press 1 to create a combo, 2 to view menu, 0 to exit");
            int choice = scanner.nextInt();
            scanner.nextLine();

            if (choice == 1) {
                menu.createCustomCombo();
            } else if (choice == 2) {
                menu.viewMenu();
            } else if (choice == 0) {
                break;
            }
        }
    }
}
