public interface MenuItem {
    String getName();
    int getPrice();
    void display();
}