import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Menu {
    private List<MenuItem> items = new ArrayList<>();

    public void addMenuItem(MenuItem item) {
        items.add(item);
    }

    public void viewMenu() {
        System.out.println("Menu:");
        items.forEach(MenuItem::display);
    }

    public void createCustomCombo() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the name of the combo: ");
        String name = scanner.nextLine();

        Combo combo = new Combo(name);

        while (true) {
            System.out.println("Available commands: Add [item name], Remove [item name], Free [item name], Discount [percentage], Done");
            String command = scanner.nextLine();

            if (command.startsWith("Add ")) {
                String itemName = command.substring(4);
                items.stream()
                        .filter(item -> item.getName().equals(itemName))
                        .findFirst()
                        .ifPresent(combo::addItem);
            }
            else if (command.startsWith("Remove ")) {
                String itemName = command.substring(7);
                items.stream()
                        .filter(item -> item.getName().equals(itemName))
                        .findFirst()
                        .ifPresent(combo::removeItem);
            }
            else if (command.startsWith("Free ")) {
                String itemName = command.substring(5);
                items.stream()
                        .filter(item -> item.getName().equals(itemName))
                        .findFirst()
                        .ifPresent(item -> combo.addItem(new IndividualItem(item.getName() + " (Free)", 0)));
            }
            else if (command.startsWith("Discount ")) {
                int percentage = Integer.parseInt(command.substring(9));
                combo.applyDiscount(percentage);
            }
            else if (command.equals("Done")) {
                break;
            }
        }
        addMenuItem(combo);
        System.out.println("Custom combo created:");
        combo.display();
    }
}
