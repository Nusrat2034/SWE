import java.util.ArrayList;
import java.util.List;

class Combo implements MenuItem {
    private String name;
    private List<MenuItem> items = new ArrayList<>();
    private int discount = 0;

    public Combo(String name) {
        this.name = name;
    }

    public void addItem(MenuItem item) {
        items.add(item);
    }

    public void removeItem(MenuItem item) {
        items.remove(item);
    }

    public void applyDiscount(int percentage) {
        this.discount = percentage;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public int getPrice() {
        int total = items.stream().mapToInt(MenuItem::getPrice).sum();
        return total - (total * discount / 100);
    }

    @Override
    public void display() {
        System.out.println(name + " (Combo):");
        items.forEach(MenuItem::display);
        System.out.println("Total - " + getPrice() + "tk (Discount: " + discount + "%)");
    }
}